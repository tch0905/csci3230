Refer to https://inst.eecs.berkeley.edu/~cs188/su20/project1/
Do not copy answer from any website!!!!!!!!!
